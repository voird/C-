﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace SQLproject
{
    public partial class addProduct : Form
    {
        public NpgsqlConnection con;
        public int id;

        public addProduct(NpgsqlConnection con, int id)
        {
            this.id = id;
            this.con = con;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonNo_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonYes_Click(object sender, EventArgs e)
        {
            try
            {


                if (id == 0) { 
                    NpgsqlCommand command = new NpgsqlCommand("INSERT INTO Product (name,ed) VALUES (:name, :ed)", con);
                    command.Parameters.AddWithValue("name", textBox1.Text);
                    command.Parameters.AddWithValue("ed", textBox2.Text);
                    command.ExecuteNonQuery();
                    Close();
                }

                if(id != 0) {
                    NpgsqlCommand command = new NpgsqlCommand("UPDATE Product SET name = :name, ed =:ed WHERE id = :id", con);
                    command.Parameters.AddWithValue("name", textBox1.Text);
                    command.Parameters.AddWithValue("ed", textBox2.Text);
                    command.Parameters.AddWithValue("id", id);
                    command.ExecuteNonQuery();
                    Close();
                }
            }
            catch { }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void addProduct_Load(object sender, EventArgs e)
        {
            if(id != 0) { 
                NpgsqlCommand command = new NpgsqlCommand("SELECT name, ed FROM Product WHERE id = :id", con);
                command.Parameters.AddWithValue("id", id);
                NpgsqlDataReader reader = command.ExecuteReader();
                Console.WriteLine(id);
                reader.Read();
                textBox1.Text = reader.GetString(0);
                textBox2.Text = reader.GetString(1);
                reader.Close();
                command.Cancel();
            }
        }
    }
}

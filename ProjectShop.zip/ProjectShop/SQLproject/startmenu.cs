﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace SQLproject
{
  
    public partial class startmenu : Form
    {
        public NpgsqlConnection con;
        public startmenu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MyLoad();
        }

        public void MyLoad()
        {
            StartPosition = FormStartPosition.CenterScreen;
            con = new NpgsqlConnection("Server=localhost;Port=5432;UserID=postgres;Password=postpass;Database=STOROZHEVA");
            con.Open();
            Console.WriteLine("Connection done");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            controlProduct cP = new controlProduct(con);
            cP.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            controlProduct cP = new controlProduct(con);
            cP.ShowDialog();
        }
    }
}
